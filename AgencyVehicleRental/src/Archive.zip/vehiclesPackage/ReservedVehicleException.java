
package vehiclesPackage;

public class ReservedVehicleException extends Exception {
    
}
