package vehiclesPackage;

public interface costType 
{
    public double getDailyRate();
    public double getWeeklyRate();
    public double getMonthlyRate();
    public double getMileageChrg(); 
    public double getDailyInsurRate();
}
