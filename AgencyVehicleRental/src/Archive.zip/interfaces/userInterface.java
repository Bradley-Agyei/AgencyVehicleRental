package interfaces;

public interface userInterface 
{
    public void start(); 
}
